package cl.bruntcontrol

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import javax.net.ssl.HttpsURLConnection

/**
 * Android port of the HTTP behaviour used by AmyJeanes/brunt-api.
 *
 * Original API behaviour:
 * POST https://sky.brunt.co/session
 * GET  https://sky.brunt.co/thing
 * GET/PUT https://thing.brunt.co:8080/thing{thingUri}
 *
 * This is an unofficial API and can stop working if Brunt changes its service.
 */
class BruntApi {

    private val accept = "application/vnd.brunt.v1+json"
    private val userAgent =
        "Mozilla/5.0 (iPhone; CPU iPhone OS 11_3 like Mac OS X) " +
        "AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E216"

    fun login(username: String, password: String): BruntLogin {
        val payload = JSONObject()
            .put("ID", username)
            .put("PASS", password)
            .toString()

        val conn = openHttps(
            url = "https://sky.brunt.co/session",
            method = "POST",
            body = payload
        )

        val body = readResponse(conn)
        val json = JSONObject(body)
        val status = json.optString("status")

        if (status != "activate") {
            throw IllegalStateException("Inicio de sesión rechazado por Brunt.")
        }

        val sessionId = extractSessionCookie(conn)
            ?: json.optString("sessionId").takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("Brunt no devolvió una sesión válida.")

        return BruntLogin(
            nickname = json.optString("nickname", username),
            status = status,
            sessionId = sessionId
        )
    }

    fun getThings(sessionId: String): List<BruntThing> {
        val conn = openHttps(
            url = "https://sky.brunt.co/thing",
            method = "GET",
            sessionId = sessionId
        )

        val array = JSONArray(readResponse(conn))
        return buildList {
            for (i in 0 until array.length()) {
                val j = array.getJSONObject(i)
                add(
                    BruntThing(
                        name = j.optString("NAME", "Cortina"),
                        serial = j.optString("SERIAL"),
                        model = j.optString("MODEL"),
                        currentPosition = j.optString("currentPosition", "0").toIntOrNull() ?: 0,
                        requestPosition = j.optString("requestPosition", "0").toIntOrNull() ?: 0,
                        thingUri = j.optString("thingUri")
                    )
                )
            }
        }
    }

    fun getState(sessionId: String, thingUri: String): BruntThing {
        val conn = openHttps(
            url = "https://thing.brunt.co:8080/thing$thingUri",
            method = "GET",
            sessionId = sessionId
        )

        val j = JSONObject(readResponse(conn))
        return BruntThing(
            name = j.optString("NAME", "Cortina"),
            serial = j.optString("SERIAL"),
            model = j.optString("MODEL"),
            currentPosition = j.optString("currentPosition", "0").toIntOrNull() ?: 0,
            requestPosition = j.optString("requestPosition", "0").toIntOrNull() ?: 0,
            thingUri = thingUri
        )
    }

    fun changePosition(sessionId: String, thingUri: String, position: Int): Boolean {
        require(position in 0..100)

        val payload = JSONObject()
            .put("requestPosition", position.toString())
            .toString()

        val conn = openHttps(
            url = "https://thing.brunt.co:8080/thing$thingUri",
            method = "PUT",
            body = payload,
            sessionId = sessionId
        )

        readResponse(conn)
        return conn.responseCode == HttpURLConnection.HTTP_OK
    }

    private fun openHttps(
        url: String,
        method: String,
        body: String? = null,
        sessionId: String? = null
    ): HttpsURLConnection {
        val conn = URL(url).openConnection() as HttpsURLConnection
        conn.requestMethod = method
        conn.connectTimeout = 12_000
        conn.readTimeout = 15_000
        conn.setRequestProperty("Accept", accept)
        conn.setRequestProperty("Accept-Language", "en-gb")
        conn.setRequestProperty("User-Agent", userAgent)

        if (sessionId != null) {
            // Deliberately kept exactly as used by the original library.
            conn.setRequestProperty("Cookie", "skySSEIONID=$sessionId")
        }

        if (body != null) {
            conn.doOutput = true
            // The original library sends JSON while declaring this content type.
            conn.setRequestProperty(
                "Content-Type",
                "application/x-www-form-urlencoded; charset=UTF-8"
            )
            conn.setRequestProperty("Origin", "https://sky.brunt.co")
            val bytes = body.toByteArray(Charsets.UTF_8)
            conn.setRequestProperty("Content-Length", bytes.size.toString())
            conn.outputStream.use { it.write(bytes) }
        }

        return conn
    }

    private fun readResponse(conn: HttpsURLConnection): String {
        val code = conn.responseCode
        val stream =
            if (code in 200..299) conn.inputStream
            else conn.errorStream ?: conn.inputStream

        val text = BufferedReader(InputStreamReader(stream)).use { reader ->
            reader.readText()
        }

        if (code !in 200..299) {
            throw IllegalStateException("Error Brunt HTTP $code: ${text.take(300)}")
        }

        return text
    }

    private fun extractSessionCookie(conn: HttpsURLConnection): String? {
        val cookies = conn.headerFields["Set-Cookie"] ?: return null

        return cookies
            .asSequence()
            .flatMap { it.split(";").asSequence() }
            .map { it.trim() }
            .firstOrNull { it.startsWith("skySSEIONID=") }
            ?.substringAfter("=")
            ?.takeIf { it.isNotBlank() }
    }
}
