package cl.bruntcontrol

import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.slider.Slider
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private val api = BruntApi()
    private val executor = Executors.newSingleThreadExecutor()

    private lateinit var root: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var usernameInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var loginButton: MaterialButton
    private lateinit var deviceContainer: LinearLayout
    private lateinit var progress: ProgressBar

    private var sessionId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(32))
        }
        scroll.addView(root)

        root.addView(TextView(this).apply {
            text = "Brunt Control"
            textSize = 30f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })

        root.addView(TextView(this).apply {
            text = "Control simple para Brunt Blind Engine"
            textSize = 16f
            setPadding(0, dp(4), 0, dp(22))
        })

        usernameInput = EditText(this).apply {
            hint = "Usuario / correo Brunt"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            singleLine = true
        }
        root.addView(usernameInput, matchWrap())

        passwordInput = EditText(this).apply {
            hint = "Contraseña"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            singleLine = true
        }
        root.addView(passwordInput, matchWrap())

        loginButton = MaterialButton(this).apply {
            text = "CONECTAR"
            setOnClickListener { login() }
        }
        root.addView(loginButton, matchWrap(top = 12))

        progress = ProgressBar(this).apply {
            visibility = View.GONE
        }
        root.addView(progress, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            topMargin = dp(12)
        })

        statusText = TextView(this).apply {
            text = "Ingresa tus credenciales Brunt."
            textSize = 14f
            setPadding(0, dp(12), 0, dp(12))
        }
        root.addView(statusText, matchWrap())

        deviceContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        root.addView(deviceContainer, matchWrap())

        setContentView(scroll)
    }

    private fun login() {
        val user = usernameInput.text.toString().trim()
        val password = passwordInput.text.toString()

        if (user.isBlank() || password.isBlank()) {
            toast("Ingresa usuario y contraseña.")
            return
        }

        busy(true, "Conectando con Brunt…")

        executor.execute {
            try {
                val login = api.login(user, password)
                sessionId = login.sessionId
                val things = api.getThings(login.sessionId)

                runOnUiThread {
                    passwordInput.text.clear()
                    statusText.text =
                        if (things.isEmpty()) "Conectado como ${login.nickname}. No se encontraron dispositivos."
                        else "Conectado como ${login.nickname}. ${things.size} dispositivo(s)."
                    renderDevices(things)
                    busy(false)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    busy(false)
                    statusText.text = "No fue posible conectar."
                    toast(e.message ?: "Error de conexión")
                }
            }
        }
    }

    private fun renderDevices(things: List<BruntThing>) {
        deviceContainer.removeAllViews()
        things.forEach { thing -> deviceContainer.addView(deviceCard(thing)) }
    }

    private fun deviceCard(initialThing: BruntThing): View {
        val card = MaterialCardView(this).apply {
            radius = dp(18).toFloat()
            cardElevation = dp(2).toFloat()
            useCompatPadding = true
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(18))
        }
        card.addView(box)

        val title = TextView(this).apply {
            text = initialThing.name
            textSize = 20f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        box.addView(title)

        val model = TextView(this).apply {
            text = listOf(initialThing.model, initialThing.serial)
                .filter { it.isNotBlank() }
                .joinToString(" • ")
            textSize = 12f
        }
        box.addView(model)

        val positionText = TextView(this).apply {
            text = "${initialThing.currentPosition}% abierto"
            textSize = 16f
            setPadding(0, dp(12), 0, dp(4))
        }
        box.addView(positionText)

        val slider = Slider(this).apply {
            valueFrom = 0f
            valueTo = 100f
            stepSize = 5f
            value = initialThing.currentPosition.coerceIn(0, 100).toFloat()
        }
        box.addView(slider, matchWrap())

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        fun actionButton(label: String, target: Int): MaterialButton =
            MaterialButton(this).apply {
                text = label
                setOnClickListener {
                    slider.value = target.toFloat()
                    move(initialThing, target, positionText)
                }
            }

        buttons.addView(actionButton("CERRAR", 0), weighted())
        buttons.addView(actionButton("50%", 50), weighted(left = 6, right = 6))
        buttons.addView(actionButton("ABRIR", 100), weighted())
        box.addView(buttons, matchWrap(top = 8))

        val apply = MaterialButton(this).apply {
            text = "MOVER A LA POSICIÓN ELEGIDA"
            setOnClickListener {
                move(initialThing, slider.value.toInt(), positionText)
            }
        }
        box.addView(apply, matchWrap(top = 8))

        val refresh = Button(this).apply {
            text = "Actualizar estado"
            setOnClickListener {
                refreshState(initialThing, slider, positionText)
            }
        }
        box.addView(refresh, matchWrap(top = 6))

        return card
    }

    private fun move(thing: BruntThing, position: Int, positionText: TextView) {
        val sid = sessionId ?: return
        positionText.text = "Moviendo a $position%…"

        executor.execute {
            try {
                api.changePosition(sid, thing.thingUri, position)
                Thread.sleep(900)
                val state = runCatching { api.getState(sid, thing.thingUri) }.getOrNull()

                runOnUiThread {
                    val shown = state?.currentPosition ?: position
                    positionText.text = "$shown% abierto"
                    toast("Orden enviada: $position%")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    positionText.text = "Error al mover"
                    toast(e.message ?: "No se pudo mover la cortina")
                }
            }
        }
    }

    private fun refreshState(thing: BruntThing, slider: Slider, positionText: TextView) {
        val sid = sessionId ?: return
        positionText.text = "Actualizando…"

        executor.execute {
            try {
                val state = api.getState(sid, thing.thingUri)
                runOnUiThread {
                    slider.value = state.currentPosition.coerceIn(0, 100).toFloat()
                    positionText.text = "${state.currentPosition}% abierto"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    positionText.text = "No se pudo actualizar"
                    toast(e.message ?: "Error")
                }
            }
        }
    }

    private fun busy(value: Boolean, text: String? = null) {
        progress.visibility = if (value) View.VISIBLE else View.GONE
        loginButton.isEnabled = !value
        if (text != null) statusText.text = text
    }

    private fun toast(text: String) =
        Toast.makeText(this, text, Toast.LENGTH_LONG).show()

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun matchWrap(top: Int = 0) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(top) }

    private fun weighted(left: Int = 0, right: Int = 0) = LinearLayout.LayoutParams(
        0,
        LinearLayout.LayoutParams.WRAP_CONTENT,
        1f
    ).apply {
        leftMargin = dp(left)
        rightMargin = dp(right)
    }
}
