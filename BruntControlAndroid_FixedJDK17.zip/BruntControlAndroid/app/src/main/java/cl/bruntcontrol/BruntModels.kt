package cl.bruntcontrol

data class BruntLogin(
    val nickname: String,
    val status: String,
    val sessionId: String
)

data class BruntThing(
    val name: String,
    val serial: String,
    val model: String,
    val currentPosition: Int,
    val requestPosition: Int,
    val thingUri: String
)
