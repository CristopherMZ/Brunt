# Brunt Control para Android

Aplicación Android sencilla para controlar dispositivos Brunt Blind Engine mediante la API no oficial usada por el proyecto `AmyJeanes/brunt-api`.

## Funciones

- Login con cuenta Brunt.
- Listado de dispositivos asociados.
- Visualización de posición.
- Abrir al 100%.
- Cerrar al 0%.
- Posición 50%.
- Slider de 0 a 100%.
- Actualizar estado manualmente.

## API reproducida

El proyecto original utiliza:

- `POST https://sky.brunt.co/session`
- `GET https://sky.brunt.co/thing`
- `GET https://thing.brunt.co:8080/thing{thingUri}`
- `PUT https://thing.brunt.co:8080/thing{thingUri}`

La sesión se envía mediante la cookie `skySSEIONID`.

> Importante: es una API no oficial. El repositorio original fue archivado, por lo que Brunt puede modificar o retirar estos endpoints.

## Abrir el proyecto

1. Instala Android Studio.
2. Descomprime `BruntControlAndroid.zip`.
3. En Android Studio: **Open** y selecciona la carpeta `BruntControlAndroid`.
4. Espera a que Gradle descargue las dependencias.
5. Conecta un teléfono Android con depuración USB o usa un emulador.
6. Presiona **Run ▶**.

## Crear APK

En Android Studio:

**Build → Build App Bundle(s) / APK(s) → Build APK(s)**

El APK debug quedará normalmente en:

`app/build/outputs/apk/debug/app-debug.apk`

## Seguridad

La app no guarda la contraseña. La sesión existe solamente mientras la app está ejecutándose.

No publiques un APK con credenciales incorporadas en el código.


## Compilar el APK directamente en GitHub

Este proyecto incluye GitHub Actions, así que no necesitas Android Studio para generar el APK.

1. Crea un repositorio nuevo en GitHub.
2. Sube todo el contenido de la carpeta `BruntControlAndroid`.
3. Abre la pestaña **Actions** del repositorio.
4. Selecciona **Build Android APK**.
5. Pulsa **Run workflow**.
6. Cuando termine, abre la ejecución.
7. En **Artifacts**, descarga `BruntControl-debug-apk`.
8. Descomprime el archivo descargado y encontrarás `app-debug.apk`.
9. Pasa el APK a tu teléfono e instálalo.

También se compila automáticamente cada vez que hagas un push a `main` o `master`.

### Si GitHub muestra un error

Copia el texto rojo de la etapa que falló o envía una captura. Con eso se puede ajustar el proyecto o la configuración de Gradle.
